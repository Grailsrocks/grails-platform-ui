navigation = {
    dev(global:true) {
        platformUi(action:'index') {
            uisets()
            themes()
        }
    }
}