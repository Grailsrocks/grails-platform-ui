modules = {
    'theme._default' {
        
    }
    
    'theme._default.main' {
        
    }
    
    'ui._default' {
        
    }
}