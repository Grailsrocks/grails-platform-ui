modules ={
	'plugin.platformUi.tools' {
		resource url:[plugin:'platformUi', dir:'css', file:'platformUi.css']
	}
}