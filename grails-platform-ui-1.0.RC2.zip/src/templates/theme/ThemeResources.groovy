modules = {
    // Global resources for all layouts
    'theme.@artifact.name@' {
        
    }
    
    // Per-layout resources
    'theme.@artifact.name@.layoutName' {
        
    }
}
